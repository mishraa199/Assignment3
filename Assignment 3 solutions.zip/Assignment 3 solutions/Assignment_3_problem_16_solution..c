//Write a program to check whether a given character is an alphabet (uppercase),
//an alphabet (lower case),
//a digit or a special character.
#include <stdio.h>
int main()
{

    char ch;
    printf("Enter any charcter");
    scanf("%ch",&ch);
    if (ch>='a' && ch<='z')
        printf("Lower Case");
    else if (ch>='A' && ch<='Z')
        printf("UPPER CASE");
    else if (ch>='0' && ch<='9')
        printf("Digit");
    else
        printf("Special charcter");
    return 0;
}
