#include <stdio.h>

int main ()
{
    int num1,num2;
    printf("Enter two numbers\n");
    scanf("%d%d",&num1,&num2);
    if(num1 > num2)
    {
        printf("%d is greater then %d",num1,num2);
    }
    if(num2 > num1)
    {
        printf("%d is greater then %d",num2,num1);
    }
    if(num1==num2)
    {
        printf("%d and %d Both are the same",num1,num2);

    }
    return 0;
}
