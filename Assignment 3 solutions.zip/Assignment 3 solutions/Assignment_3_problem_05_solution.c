#include <stdio.h>
int main()
{
    int number, reminder=0,sum=0;
    printf("Enter the number: ");
    scanf("%d",&number);
    if(number>=99 && number<=999)
    {
        printf("%d is a Three digit number",number);
              while(number !=0)
              {
                  reminder= number%10;
                  sum= sum+reminder;
                  number= number/10;
              }
              printf("Sum of the digit is %d",sum);

    }
    else
    {
        printf("%d is not a three digit Number",number);
    }
    return 0;
}
