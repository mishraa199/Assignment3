/*Write a program which takes the cost price and selling price of a product from the
user. Now calculate and print profit or loss percentage.*/
#include <stdio.h>
int main ()
{
    int cp,sp;
    float profit,loss;
    printf("Enter the cost price: ");
    scanf("%d",&cp);
    printf("Enter the selling price: ");
    scanf("%d",&sp);
    if(sp>cp)
{
     profit = sp-cp;
     profit = (profit/cp)*100;
     printf("Profit percentage = %.2f",profit);
}

    else if (cp>sp)
    {
        loss= cp-sp;
        loss= (loss/cp)*100;
        printf(" Loss percentage = %.2f",loss);

    }
    else
        printf("No profit no Loss");

   return 0;
}
