//Write a program to check whether a given year is a leap year or not.
#include <stdio.h>
int main()
{

    int year;
    printf("\nEnter the year: ");
    scanf("%d",&year);
    if (year%4==0)
        printf("Leap year");
    else if (year%400==0)
        printf("Leap year");
    else
        printf("Non leap year");
    return 0;
}
