//Write a program to check whether a given alphabet is in uppercase or lowercase.
#include <stdio.h>
int main ()
{
    char c;
    printf("Enter any charcter");
    scanf("%c",&c);
    if(c>='A'&& c<='Z')
        printf("Upper case");
    else if (c>='a' && c<='z')
        printf("Lower case");
    return 0;
}
