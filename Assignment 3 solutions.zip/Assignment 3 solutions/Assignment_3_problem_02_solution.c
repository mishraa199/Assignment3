#include <stdio.h>

int main ()
{
    int number;
    printf("Enter number ");
    scanf("%d",&number);
    //Using if else control statement
    if (number%5==0)
    {
        printf("%d is Divisible by 5",number);
    }
    else
    {
        printf ("%d is not divisible by 5",number);
    }
    return 0;
}

//Below using conditional operator
/*number%5==0?printf("%d Is Divisible by 5",number):printf("%d Is Not Divisible by 5",number);
return 0;
}
*/
