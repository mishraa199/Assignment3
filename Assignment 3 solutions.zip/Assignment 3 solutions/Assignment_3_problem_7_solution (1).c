#include <stdio.h>

int main()
{
    int a,b,c,disc;
    printf("Enter the value of a, b and c\n");
    scanf("%d %d %d",&a, &b, &c);
    disc= b*b-4*a*c;
    if(disc>0)
    {
       printf("Real and Distinct");
    }
    else if(disc<0)
    {
        printf("Imaginary roots");
    }
    else
    {
        printf("Real and Equal");
    }
    return 0;

}
